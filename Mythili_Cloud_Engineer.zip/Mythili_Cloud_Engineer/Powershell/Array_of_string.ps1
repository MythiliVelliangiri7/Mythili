﻿$a= @('January 2024 has 4 saturdays', 'Februray 2024 has 3 saturdays', 'March has 5 Mondays and 4 Saturdays', 'April has 5 Sundays', 'May has 5 Tuesdays and 4 Saturdays')
$b= Read-Host "Enter keyword to find"
$a -match $b
